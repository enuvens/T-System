function ValidaLogin(frm){
    if(frm.email.value == "" || frm.email.value == null) {
      frm.email.focus();
      document.getElementById('email').style = 'border: 1px solid #FF0000';
      return false;
    }
    if(frm.senha.value == "" || frm.senha.value == null) {
      frm.senha.focus();
      document.getElementById('senha').style = 'border: 1px solid #FF0000';
      return false;
    }
  
    if (frm.email.value == "user@area.com" && frm.senha.value == "123456"){
      return true;
    } else {
      window.alert('Login ou senha inválidos!');
      return false;
    }
}

$(document).ready(function() {

console.log('    ______     __    __     ______     ______     ______      ______   ______     ______     ______   ______     ______     __  __    ');
console.log('    /\  ___\   /\ "-./  \   /\  __ \   /\  == \   /\__  _\    /\  ___\ /\  __ \   /\  ___\   /\__  _\ /\  __ \   /\  == \   /\ \_\ \   ');
console.log('    \ \___  \  \ \ \-./\ \  \ \  __ \  \ \  __<   \/_/\ \/    \ \  __\ \ \  __ \  \ \ \____  \/_/\ \/ \ \ \/\ \  \ \  __<   \ \____ \  ');
console.log('     \/\_____\  \ \_\ \ \_\  \ \_\ \_\  \ \_\ \_\    \ \_\     \ \_\    \ \_\ \_\  \ \_____\    \ \_\  \ \_____\  \ \_\ \_\  \/\_____\ ');
console.log('      \/_____/   \/_/  \/_/   \/_/\/_/   \/_/ /_/     \/_/      \/_/     \/_/\/_/   \/_____/     \/_/   \/_____/   \/_/ /_/   \/_____/ ');

console.log('');
console.log('');

console.log('Desenvolvido por Danielle, Eduardo, Leticia, Marcus e Mayara');
});